package com.example.bburecog;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
